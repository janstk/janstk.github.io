package so.raw.XMLDemo;

import java.io.IOException;
import java.util.List;

import so.raw.util.*;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Entity;
import org.dom4j.io.SAXReader;
import org.junit.Test;
import org.xml.sax.DocumentHandler;
import org.xml.sax.SAXException;

public class Dom4jDemo {

	/**
	 * 查询 查询第一个student元素下的name元素的文本 查询第二个student元素下的number属性值
	 * 
	 * @throws SAXException
	 * @throws DocumentException
	 * @throws ParserConfigurationException
	 */
	// @Test
	public void find() throws SAXException, DocumentException {
		SAXReader reader = new SAXReader();
		Document doc = reader.read("test.xml");
		Element rootElement = doc.getRootElement();

		String text = rootElement.element("student").element("name").getText();
		System.out.println(text);

	}

	/**
	 * 添加 给第一个student元素添加 country='zh' 给第二个student元素添加<score>99</score>
	 * 
	 * @throws DocumentException
	 * @throws IOException
	 */
//	@Test
	public void add() throws DocumentException, IOException {
		SAXReader reader = new SAXReader();
		Document document = reader.read("test.xml");
		Element rootElement = document.getRootElement();
		// 操作学生1
		Element student1 = rootElement.element("student");
		student1.addAttribute("country", "zh_CN");
		// 操作学生二
		List list = rootElement.elements("student");
		Element student2 = (Element) list.get(1);
		Element score = DocumentHelper.createElement("score");
		score.add(DocumentHelper.createText("99"));
		student2.add(score);

		// 回写

		Dom4jutil.write2xml(document, "test1.xml");
	}

	/**
	 * 添加一个student元素 <student number="s003" country="陕西"> <name>王五</name>
	 * <age>25</age> <sex>male</sex> </student>
	 * 
	 * @throws DocumentException
	 */
//	@Test
	public void add2() throws Exception{
		
		Document document = Dom4jutil.getDocument("test.xml");
		Element rootElement = document.getRootElement();
		String text = "<student number=\"s003\" country=\"陕西\">"+
		"<name>王五</name>"+
		"<age>25</age>"+
		"<sex>male</sex>"+
		"</student>";
		Document doc2 = DocumentHelper.parseText(text);
		rootElement.add(doc2.getRootElement());
		Dom4jutil.write2xml(document, "test2.xml");
		
		
	}

	/**
	 * 删除 将第一个student元素的 country='zh'删除 将第二个student元素的<score>99</score> 删除
	 * @throws DocumentException 	
	 * @throws IOException 
	 */
//	@Test
	public void delete() throws DocumentException, IOException {
		String filename = "test1.xml";
		Document document = Dom4jutil.getDocument(filename);
		Element rootElement = document.getRootElement();
		Element student1 = rootElement.element("student");
		student1.remove(student1.attribute("country"));
		
		List list = rootElement.elements("student");
		Element student2 = (Element) list.get(1);
		student2.remove(student2.element("score"));
		
		Dom4jutil.write2xml(document, filename);
		
		
	}

	/**
	 * 修改 修改第一个student的属性 number='s005' 修改第二个student元素的子元素name 文本为 wangwu
	 * @throws DocumentException 
	 * @throws IOException 
	 */
	@Test
	public void update() throws DocumentException, IOException {
		Document document = Dom4jutil.getDocument("test1.xml");
		Element rootElement = document.getRootElement();
		List list = rootElement.elements("student");
		Element student1 = (Element) list.get(0);
		student1.addAttribute("number", "s005");
		Element student2 = (Element) list.get(1);
		student2.element("name").setText("wangwu");
		
		Dom4jutil.write2xml(document, "test3.xml");
	}
}

