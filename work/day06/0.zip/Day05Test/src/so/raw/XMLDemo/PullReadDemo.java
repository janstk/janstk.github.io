package so.raw.XMLDemo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import so.raw.domain.Student;

public class PullReadDemo {

	@Test
	public void test1() throws XmlPullParserException, NumberFormatException, IOException {
		XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
		XmlPullParser parser = factory.newPullParser();
		parser.setInput(new FileInputStream("students.xml"), "utf-8");
		int type = parser.getEventType();
		List<Student> stuList = null;
		Student stu = null;
		while (type != XmlPullParser.END_DOCUMENT) {
			String tagName = parser.getName();
			switch (type) {
			case XmlPullParser.START_TAG:
				if("students".equals(tagName))
				{
					stuList = new ArrayList<Student>();
				}else if("student".equals(tagName))
				{
					stu = new Student();
					stu.setId(parser.getAttributeValue(0));
				}else if("name".equals(tagName))
				{
					stu.setName(parser.nextText());
				}else if("age".equals(tagName))
				{
					stu.setAge(Integer.parseInt(parser.nextText()));
				}else if("sex".equals(tagName))
				{
					stu.setSex(parser.nextText());
				}
				break;
			case XmlPullParser.END_TAG:
				if("student".equals(tagName))
				{
					stuList.add(stu);
					stu = null;
				}
				break;
			default:
				break;
			}
			type = parser.next(); // 直接通过next方法即可获取下次的事件返回值。
		}
		System.out.println(stuList);
	}
}
