package so.raw.XMLDemo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import org.xmlpull.v1.XmlSerializer;

import so.raw.domain.Student;

public class PullWriterDemo {

	public static void main(String[] args) throws IllegalArgumentException, IllegalStateException, FileNotFoundException, XmlPullParserException, IOException {
		ArrayList<Student> students = new ArrayList<Student>();
		students.add(new Student("zhangsan",23,"male","s001"));
		students.add(new Student("李四",24,"female","s002"));
		students.add(new Student("王五",25,"male","s005"));
		students.add(new Student("兆流",26,"female","s006"));
		students.add(new Student("王尼玛",23,"male","s009"));
		
		writeList2xml(students,"test.xml");
		
	}
	public static void writeList2xml(List<Student> students,String filename) throws XmlPullParserException, IllegalArgumentException, IllegalStateException, FileNotFoundException, IOException
	{
		//创建工厂
		XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
		//创建实例化对象
		XmlSerializer serializer = factory.newSerializer();
		//设置输出流
		serializer.setOutput(new FileOutputStream(filename),"utf-8");
		//开始文档
		serializer.startDocument("utf-8", null);
		serializer.startTag(null, "students");
		
		
		 // 开始写入信息。
		
		for(Student s:students)
		{
			serializer.startTag(null,"student");
			serializer.attribute(null, "id", s.getId());
			
			serializer.startTag(null, "name");
			serializer.text(s.getName());
			serializer.endTag(null, "name");
			
			serializer.startTag(null, "age");
			serializer.text(s.getAge()+"");
			serializer.endTag(null, "age");
			
			serializer.startTag(null, "sex");
			serializer.text(s.getSex());
			serializer.endTag(null, "sex");
			
			serializer.endTag(null,"student");
			
		}
		
		
		
		
		
		serializer.endTag(null, "students");
		//结束文档
		serializer.endDocument();
		
		
		
	}
	public void test() throws XmlPullParserException, IllegalArgumentException, IllegalStateException, FileNotFoundException, IOException
	{
		//创建工厂
		XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
		//获取序列化对象。
		XmlSerializer serializer = factory.newSerializer();
		//设置输出目的地和编码。
		
		serializer.setOutput(new FileOutputStream("test.xml"), "utf-8");
		//开始写入。
		//开始文档。
		/**
		 * 	开始文档用startDocument,结束文档用endDocument
		 *  开始标签 用startTag 、结束标签用endTag
		 *  设置属性用attribute 
		 *  设置文本用text
		 *  
		 */
		serializer.startDocument("utf-8", true);
		serializer.startTag(null, "students");
		serializer.attribute(null, "id", "s001");
		serializer.text("wenben");
		serializer.endTag(null, "students");
		//结束文档。
		serializer.endDocument();
		
	}
	
}
