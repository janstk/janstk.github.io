package so.raw.util;


import java.io.FileOutputStream;
import java.io.IOException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class Dom4jutil {

	public static void write2xml(Document doc,String filename) throws IOException
	{
		XMLWriter  xmlw = 
				new XMLWriter(new FileOutputStream(filename), OutputFormat.createPrettyPrint());
	
		xmlw.write(doc);
	}
	public static Document getDocument(String filename) throws DocumentException
	{
		SAXReader reader = new SAXReader();
		return reader.read(filename);
	}
}
