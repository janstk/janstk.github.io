package so.raw.dao;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import so.raw.domain.Product;

public class ProductDao {

	private String filename = "products.xml"; 

	private Document getDocument() throws DocumentException {
		SAXReader reader = new SAXReader();
		Document document = reader.read(filename);
		return document;
	}

	private void write2xml(Document document) throws IOException {
		OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(
				filename), "utf-8");
		XMLWriter writer = new XMLWriter(osw);
		writer.write(document);
		writer.close();
	}

	/**
	 * 
	 * @param product
	 * @throws DocumentException
	 * @throws IOException
	 */
	public void add(Product product) throws DocumentException, IOException {
		String id = product.getId();
		String name = product.getName();
		double price = product.getPrice();
		int count = product.getCount();
		String description = product.getDescription();
		String productInfo = "<product id=\"" + id + "\">" + "<name>" + name
				+ "</name>" + "<price>" + price + "</price>" + "<count>"
				+ count + "</count>" + "<description>" + description
				+ "</description>" + "</product>";
		
		
		Document productDoc = DocumentHelper.parseText(productInfo);
		
		Element productElem = productDoc.getRootElement();
		
		/*Element productElem = DocumentHelper.createElement("product");
		productElem.addAttribute("id", id);
		Element nameElem = DocumentHelper.createElement("name");
		nameElem.setText(name);
		
		Element priceElem = DocumentHelper.createElement("price");
		priceElem.setText(price+"");
		
		Element countElem = DocumentHelper.createElement("count");
		countElem.setText(count+"");
		
		Element descriptionElem = DocumentHelper.createElement("description");
		descriptionElem.setText(description);*/
		
/*
		productElem.add(nameElem);
		productElem.add(priceElem);
		productElem.add(countElem);
		productElem.add(descriptionElem);*/
		
		
		Document document = getDocument();
		Element rootElement = document.getRootElement();
		
		rootElement.add(productElem);
		write2xml(document);
	}

	/**
	 * 
	 * @param id
	 * @throws DocumentException
	 * @throws IOException
	 */
	public void delete(String id) throws DocumentException, IOException {
		Document document = getDocument();
		Element rootElement = document.getRootElement();
		Node productNode = document.selectSingleNode("//product[@id='" + id
				+ "']");
		if (null != productNode) {
			rootElement.remove(productNode);
			write2xml(document);
		}

	}

	/**
	 * @param id
	 * @param product
	 * @throws DocumentException
	 * @throws IOException
	 */
	public void edit(String id, Product product) throws DocumentException,
			IOException {
		Document document = getDocument();
		Element rootElement = document.getRootElement();
		Node productOld = document.selectSingleNode("//product[@id='" + id
				+ "']");
		if (null == productOld)
			return;
		rootElement.remove(productOld);
		String id_new = product.getId();
		String name = product.getName();
		double price = product.getPrice();
		int count = product.getCount();
		String description = product.getDescription();
		String productInfo = "<product id=\"" + id_new + "\">" + "<name>"
				+ name + "</name>" + "<price>" + price + "</price>" + "<count>"
				+ count + "</count>" + "<description>" + description
				+ "</description>" + "</product>";
		Document productDoc = DocumentHelper.parseText(productInfo);
		rootElement.add(productDoc.getRootElement());
		write2xml(document);
	}

	/**
	 * 
	 * @param id
	 * @return Product
	 * @throws DocumentException
	 */
	public Product getProduct(String id) throws DocumentException {
		Document document = getDocument();
		Element rootElement = document.getRootElement();
		Element productElem = (Element) document
				.selectSingleNode("//product[@id='" + id + "']");
		if (null == productElem)
			return null;
		String name = productElem.element("name").getText();
		String price = productElem.element("price").getText();
		String count = productElem.element("count").getText();
		String description = productElem.element("description").getText();
		Product retProduct = new Product(id, name, Integer.parseInt(count),
				Double.parseDouble(price), description);
		return retProduct;
	}

	/**
	 * @return List<Product>
	 * @throws DocumentException
	 */
	public List<Product> listAll() throws DocumentException {
		Document document = getDocument();
		List listAll = document.selectNodes("//product");
		List<Product> proRetList = new ArrayList<Product>();
		for (Object elem : listAll) {
			Element productElem = (Element) elem;
			String id = productElem.attributeValue("id");
			String name = productElem.element("name").getText();
			String price = productElem.element("price").getText();
			String count = productElem.element("count").getText();
			String description = productElem.element("description").getText();
			Product p = new Product(id, name, Integer.parseInt(count),
					Double.parseDouble(price), description);
			proRetList.add(p);
		}
		return proRetList;
	}
}
