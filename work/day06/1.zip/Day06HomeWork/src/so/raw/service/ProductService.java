package so.raw.service;

import java.io.IOException;
import java.util.List;

import org.dom4j.DocumentException;

import so.raw.dao.ProductDao;
import so.raw.domain.Product;

public class ProductService {
	
	private ProductDao dao = new ProductDao();
	
	public void add(Product product)  
	{
		try {
			dao.add(product);
		} catch (DocumentException e) {
			System.out.println("XML文档错误...");
		}catch(IOException e) 
		{
			System.out.println("IO错误...");
		}
		
	}
	public void del(String id) 
	{
		try {
			dao.delete(id);
		} catch (DocumentException e) {
			System.out.println("XML文档错误...");
		} catch (IOException e) {
			System.out.println("IO错误...");
		}
		
	}
	public void edit(String id,Product product)
	{
		try {
			dao.edit(id,product);
		} catch (DocumentException e) {
			System.out.println("XML文档错误...");
		} catch (IOException e) {
			System.out.println("IO错误...");
		}
	}
	public Product get(String id)
	{
		Product p = null;
		try {
			p =  dao.getProduct("p001");
		} catch (DocumentException e) {
			System.out.println("XML文档错误...");
		}
		return p;
	}
	public List<Product> getAll()
	{
		List<Product> list = null;
		try {
			list = dao.listAll();
		} catch (DocumentException e) {
			System.out.println("XML文档错误...");
		}
		return list;
				
	}
	
}
