package so.raw.unitTest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

import org.dom4j.DocumentException;
import org.junit.Test;

import so.raw.dao.ProductDao;
import so.raw.domain.Product;
import so.raw.view.MainView;

public class UnitTest {
	
	@Test
	public void testMain() throws IOException
	{
	
		Scanner sc = new Scanner(System.in);
		System.out.println("...");
		String line = sc.next();
		System.out.println(line);
	}

//	@Test
	public void testCode() throws IOException
	{
		System.out.println("aaa");
		BufferedReader bufr = new BufferedReader(new InputStreamReader(System.in,"utf-8"));
		String line = null;
		while((line = bufr.readLine())!=null)
		{
			if("over".equals(line))
				return;
			System.out.println(line);
		}
				
		
	}
//	@Test
	public void add() throws DocumentException, IOException
	{
//		ProductDao dao = new ProductDao();
//		
//		Product product = new Product("s123s", "好了吗", 123, 12.4, "试试");
//		dao.add(product);
		System.out.println("...");
		Scanner sc = new Scanner(System.in);
		String line = sc.next();
		byte b[] = line.getBytes("GBK");
		System.out.println(new String(b,"UTF-8"));
	}
//	@Test
	public void del() throws DocumentException, IOException
	{
		ProductDao dao = new ProductDao();
		dao.delete("soo1");
		
	}
//	@Test
	public void edit() throws DocumentException, IOException
	{
		ProductDao dao = new ProductDao();
		Product product = new Product("s005", "asdsd", 1111, 12.4, "13242r3fe");
		dao.edit("soo1",product);
	}
//	@Test
	public void get() throws DocumentException
	{
		ProductDao dao = new ProductDao();
		System.out.println(dao.getProduct("p001"));
	}
//	@Test
	public void getAll() throws DocumentException
	{
		ProductDao dao = new ProductDao();
		System.out.println(dao.listAll());
	}
}
