package so.raw.hello;


import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;

public class ServletContexTest1 extends HttpServlet {
	
	public void destroy() {
		String path = this.getServletContext().getRealPath("visit.dat");
		int data = (Integer) this.getServletContext().getAttribute("visit");
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream(new FileOutputStream(path));
			oos.writeInt(data);
			oos.close();
			System.out.println(path);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		ServletContext context = this.getServletContext();
		Integer num = (Integer) context.getAttribute("visit");
		if(null == num)
			num = 0;
		num++;
		context.setAttribute("visit", num);
		response.getOutputStream().write(("������"+num+"��").getBytes());
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request,response);
	}

	public void init() throws ServletException {
		File f = new File(this.getServletContext().getRealPath("visit.dat"));
		if(f.exists())
		{
			Integer visit = null;
			try {
				visit = new ObjectInputStream(new FileInputStream(f)).readInt();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			this.getServletContext().setAttribute("visit", visit);
		}
	}

}
