package so.raw.jerrymouse.server;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

/**
 * ����һ��HTTP��Ӧ�İ���
 * 
 * @author Janstk 
 * @see http://raw.so
 */
public class HTTPResponsePack {

	private String httpversion = "HTTP/1.0"; // HTTP�汾
	private String stat = "200 OK"; // ��Ӧ״̬��
	private Map<String, String> headers = new HashMap<String, String>();
	// ��Ӧͷ
	private byte[] body = null; // ��Ӧ��
	// ���캯��
	public HTTPResponsePack(String stat, Map<String, String> headers,
			byte[] body) {
		this.stat = (stat == null ? "200 OK" : stat);
		this.headers = headers;
		this.body = body;
	};
	//���ñ�����Ӧ��Mime����
	public void setMimetype(String type) {
		headers.put("Content-Type: ", type);
	}

	//���˴���Ӧת��Ϊ�ֽ����飬����ͳ�ȥ
	public byte[] getBytes() throws UnsupportedEncodingException {
		StringBuilder sb = new StringBuilder();
		sb.append(httpversion + " ");
		sb.append(stat + " " + "\n");
		if (null != headers) {
			for (Map.Entry<String, String> header : headers.entrySet()) {
				if (null != header) {
					sb.append(header.getKey() + ": " + header.getValue() + "\n");
				}
			}
		}
		sb.append("\n");
		byte b[] = sb.toString().getBytes();
		byte result[] = null;
		result = new byte[b.length + body.length-1];
		for(int x=0;x<b.length;x++)
		{
			result[x] = b[x];
		}
		for(int y = b.length;y<(b.length+body.length-1);y++)
		{
			result[y] = body[y-b.length];
		}
		return result;
	}

}
