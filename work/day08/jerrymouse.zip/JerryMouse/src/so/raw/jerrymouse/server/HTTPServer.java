package so.raw.jerrymouse.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import so.raw.jerrymouse.config.JMConfig;
/**
 * ������Ҫ�ķ������ࡣ
 * @author Janstk 
 * @see http://raw.so
 */
public class HTTPServer {

	private JMConfig jmconfig = JMConfig.getInstance();
	//���ǿ�ʼ
	public void startServer() throws IOException
	{
		int port = jmconfig.getPort();
		ServerSocket ss = new ServerSocket(port);
		while(true)
		{
			Socket s  = ss.accept();
			new Thread(new HTTPSocket(s)).start();
		}
	}
}
