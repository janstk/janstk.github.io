package so.raw.jerrymouse.test;

import java.io.IOException;

import org.junit.Test;

import so.raw.jerrymouse.config.JMConfig;
import so.raw.jerrymouse.server.HTTPServer;

/**
 * ���ǵ�Ԫ������
 * @author Janstk 
 * @see http://raw.so
 *
 */
public class UTest {

	
	@Test
	public void testServer() throws IOException
	{
		HTTPServer s = new HTTPServer();
		s.startServer();
	}
	
	
//	@Test
	public void testJMConfig()
	{
		JMConfig config = JMConfig.getInstance();
//		System.out.println(config.getAppRoot());
//		System.out.println(config.getRouter("/aaa"));
//		System.out.println(config.getPort());
		System.out.println(config.getMimeType("css"));
	}
//	@Test
	public void testSplitHeader()
	{
		String line = "POST /hello/index.jsp HTTP/1.1";
		String arr[] = line.split("\\s+");
		for (String str : arr) {
			System.out.println(str);
		}
	}
//	@Test
	public void testHeader2()
	{
		String header = "Content-Type: application/x-www-form-urlencoded";
		String key = header.substring(0, header.indexOf(':'));
		String value = header.substring(header.indexOf(':') + 1).trim();
	}
}
