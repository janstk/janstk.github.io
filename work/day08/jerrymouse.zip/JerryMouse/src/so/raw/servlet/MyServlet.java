package so.raw.servlet;

import so.raw.jerrymouse.server.HTTPRequestPack;
import so.raw.jerrymouse.server.HTTPResponsePack;

/**
 * �����Զ����servlet�඼Ҫ�̳���myservlet
 * @author Janstk 
 * @see http://raw.so
 */
public abstract class MyServlet {
	
	private void MysServ() {
		init();
	}
	public abstract void init();
	public abstract HTTPResponsePack run(HTTPRequestPack request);
	public abstract void destory();
	@Override
	protected void finalize() throws Throwable {
		destory();
	}
	
}
