package so.raw.servlet;

import so.raw.jerrymouse.server.HTTPRequestPack;
import so.raw.jerrymouse.server.HTTPResponsePack;

/**
 * ����һ���򵥵�miniServlet..
 * @author Janstk 
 * @see http://raw.so
 *
 */
public class TestServer extends MyServlet {

	@Override
	public void init() {
		System.out.println("this is init method ...");
	}

	@Override
	public HTTPResponsePack run(HTTPRequestPack request) {
		//���︺����ÿ������
		HTTPResponsePack resp = null;
		System.out.println(request.getMethod());
		if(request.getMethod().equals("POST"))
		{
			System.out.println("����post����");
			resp = new HTTPResponsePack("200 OK ", null,
					"<h1 style=\"color:red\">����post����</h1>".getBytes());
			
		}
		else
		{
			System.out.println("����get����");
			resp = new HTTPResponsePack("200 OK ", null,
					"<h1 style=\"color:red\">����get����</h1>".getBytes());
			
		}
		return resp;
	}

	@Override
	public void destory() {
		// TODO Auto-generated method stub
		System.out.println("this is destroy method ...");

	}

}
