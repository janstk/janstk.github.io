package so.raw;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CheckReferer extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 1.�ж���Դ�Ƿ��뱾��host��ͬ
		String referer = request.getHeader("referer");
		String thishost = request.getHeader("host");
		if (null != referer) {
			if (!referer.contains(thishost)) {
				response.getOutputStream().write(
						"<font color=\"red\">you are not allow to this page</font>".getBytes());
				return;
			}
		}
		response.getOutputStream().write(
				"<font color=\"#009945\">you can access this page</font>".getBytes());
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
