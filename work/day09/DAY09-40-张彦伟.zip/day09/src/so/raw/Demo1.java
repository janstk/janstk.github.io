package so.raw;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.channels.WritableByteChannel;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Demo1 extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setStatus(200);
		response.getOutputStream().write("hello".getBytes());
		String method = request.getMethod();
		String path = request.getContextPath();
		String path2 = request.getServletPath();
		String queryString = request.getQueryString();
		System.out.println(queryString);
//		System.out.println(path2);
//		System.out.println(".......");
//		System.out.println(path);
//		System.out.println(method);
		String requestURI = request.getRequestURI();
		System.out.println(requestURI);
		// /day09/demo1
		StringBuffer requestURL = request.getRequestURL();
		System.out.println(requestURL);
		// http://127.0.0.1:8080/day09/demo1
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
