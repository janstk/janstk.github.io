package so.raw.cookie;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CookieDetail extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/**
		 * ��ȡ�������
		 */
		// ��ȡcookie
		Cookie[] cookies = request.getCookies();
		response.setContentType("text/html;charset=utf-8");
		// ��ȡget������Ϣ
		String productName = request.getParameter("productname");
		productName = new String(productName.getBytes("iso-8859-1"),"utf-8");
		System.out.println(productName + "...");
		productName = URLEncoder.encode(productName, "utf-8");
		boolean flag = false;
		String products = "";
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals("productname")) {
					String productsInCookie = cookie.getValue();
					if (productsInCookie.isEmpty()) {
						products = productName;
					} else if (!productsInCookie.contains(productName)) {
						products = productsInCookie + "-" + productName;
					} else {
						products = productsInCookie;

					}
					flag = true;
					break;
				}
			}
			if (!flag) {
				products = productName;
			}
		} else {
			products = URLEncoder.encode(productName, "utf-8");
		}

		/**
		 * ����cookie
		 * 
		 */
		Cookie c2 = new Cookie("productname", products);
		response.addCookie(c2);
		
		
		response.getWriter().print("<a href=\"/day10/cookie/product.jsp\">�����鿴��Ʒ</a>, " +
				"<a href=\"/day10/cookie/show.jsp\">�鿴��ʷ��¼</a>");
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

}
