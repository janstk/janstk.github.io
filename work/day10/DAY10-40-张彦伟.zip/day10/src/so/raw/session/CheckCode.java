package so.raw.session;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CheckCode extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int width = 80;
		int height = 30;
		BufferedImage im = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_RGB);
		Graphics g = im.getGraphics();
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(0, 0, width, height);
		g.setColor(Color.black);
		g.drawRoundRect(0, 0, width - 1, height - 1, 1, 1);

		int arr[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		char[] operator = { '+', '-', 'x' };
		
		Random ran = new Random();
		int a = arr[ran.nextInt(arr.length)];
		char b = operator[ran.nextInt(operator.length)];
		int c = arr[ran.nextInt(arr.length)];
		
		char[] data = {(char)(a+'0'),' ',b,' ',(char)(c+'0')};
		Integer result;
		switch (b) {
		case '+':
			result = a+c;
			break;
		case '-':
			result= a-c;
			break;
		case 'x':
			result= a*c;
			break;
		default:
			result= a+c;
			break;
		}
		request.getSession().setAttribute("checkCode", result);
		g.setColor(Color.red);
		g.drawChars(data, 0, data.length, width/3, height/2);
		
		ImageIO.write(im, "jpg", response.getOutputStream());
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}


}
