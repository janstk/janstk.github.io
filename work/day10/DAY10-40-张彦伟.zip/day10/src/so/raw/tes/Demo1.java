package so.raw.tes;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Demo1 extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		    Map<String,String[]> a = request.getParameterMap();
		    PrintStream out = System.out;
			for(Map.Entry<String,String[]> me :a.entrySet())
			{
				out.println(me.getKey()+Arrays.toString(me.getValue()));
			}
	}

}
