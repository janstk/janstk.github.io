package so.raw.dao.impl;

import java.io.IOException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;

import so.raw.dao.IfUserDao;
import so.raw.domain.User;
import so.raw.utils.Dom4JUtils;

/**
 * ����User��Dao�㡣
 * 
 * @author z
 * 
 */

public class UserDaoImpl implements IfUserDao {

	/**
	 * ���û����ӵ�xml��
	 * 
	 * @throws
	 */
	public boolean add(User user) {

		try {
			Document document = Dom4JUtils.getDocument();
			Element root = document.getRootElement();
			Element userElem = root.addElement("user");
			userElem.addAttribute("username", user.getUsername());
			userElem.addAttribute("password", user.getPassword());
			userElem.addAttribute("email", user.getEmail());
			userElem.addAttribute("birthday", user.getBirthday());
			Dom4JUtils.write2xml(document);
			return true;
		} catch (DocumentException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * ��xml�в����û�
	 */
	public User selectByUser(String username) {

		try {
			Document root = Dom4JUtils.getDocument();
			Element userElem = (Element)root.selectSingleNode("//user[@username='"+username+"']");
			if (userElem == null)
				return null;
			User user = new User(userElem.attributeValue("username"),
					userElem.attributeValue("password"),
					userElem.attributeValue("email"),
					userElem.attributeValue("birthday"));
			return user;
		} catch (DocumentException e) {
			e.printStackTrace();
			return null;
		}

	}

}
