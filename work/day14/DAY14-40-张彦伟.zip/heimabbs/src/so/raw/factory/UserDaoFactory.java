package so.raw.factory;

import java.util.ResourceBundle;

/**
 * ����UserDao �Ĺ����ࡣ
 * 
 * @author z
 * 
 */
public class UserDaoFactory {

	//���ö�ȡ��·��
	private final String USER_DAO_CLASS = ResourceBundle.getBundle(
			"so.raw.properties.userDao").getString("USERDAO");

	//����
	private UserDaoFactory() {
	}

	private static UserDaoFactory instance = new UserDaoFactory();

	public static UserDaoFactory newInstance() {
		return instance;
	}

	//��ȡʵ����
	public Object getObject() {
		try {
			Class userDaoClazz = Class.forName(USER_DAO_CLASS);
			return userDaoClazz.newInstance();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			throw new RuntimeException();
		}
		return null;
	}

}
