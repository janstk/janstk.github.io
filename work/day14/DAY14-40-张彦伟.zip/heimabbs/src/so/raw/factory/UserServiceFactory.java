package so.raw.factory;

import java.util.ResourceBundle;

/**
 * ����UserService�Ĺ���ģ�͡�
 * @author z
 *
 */
public class UserServiceFactory {
	//���ö�ȡ��·��
		private final String USERSERVICE = ResourceBundle.getBundle(
				"so.raw.properties.userService").getString("USERSERVICE");

		//����
		private UserServiceFactory() {
		}

		private static UserServiceFactory instance = new UserServiceFactory();

		public static UserServiceFactory newInstance() {
			return instance;
		}

		//��ȡʵ����
		public Object getObject() {
			try {
				Class userDaoClazz = Class.forName(USERSERVICE);
				return userDaoClazz.newInstance();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				throw new RuntimeException();
			}
			return null;
		}

}
