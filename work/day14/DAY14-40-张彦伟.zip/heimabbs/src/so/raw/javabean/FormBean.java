package so.raw.javabean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

public class FormBean {

	private String username;
	private String password;
	private String repassword;
	private String email;
	private String birthday;
	private Map<String, String> errors = new HashMap<String, String>();

	public FormBean() {

	}

	public FormBean(String username, String password, String repassword,
			String email, String birthday) {
		this.username = username;
		this.password = password;
		this.repassword = repassword;
		this.email = email;
		this.birthday = birthday;
	}

	/**
	 * ��������
	 * 
	 * @return
	 */

	public boolean test() {
		if (username == null ||  "".equals(username)) {
			errors.put("username", "�û�������Ϊ��");
		}
		if (password == null || "".equals(password)) {
			errors.put("password", "���벻��Ϊ��");

		} else if (!password.matches("\\d{3,8}")) {
			errors.put("password", "�������Ϊ3~8λ������");
		}
		if (!password.equals(repassword)) {
			errors.put("repassword", "�������벻һ��");
		}
		if (email == null ||  "".equals(email)) {
			errors.put("email", "email����Ϊ��");
		} else if (!email.matches("\\w+@\\w+(\\.\\w+)+")) {
			errors.put("email", "��������ȷ��email��ַ");
		}
		if (birthday == null || "".equals(birthday)) {
			errors.put("birthday", "���ղ���Ϊ��");
		} else {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			try {
				sdf.parse(birthday);
			} catch (ParseException e) {
				errors.put("birthday", "��������ȷ������");
			}
		}
		return errors.isEmpty();
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRepassword() {
		return repassword;
	}

	public void setRepassword(String repassword) {
		this.repassword = repassword;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public Map<String, String> getErrors() {
		return errors;
	}

}
