package so.raw.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import so.raw.domain.User;
import so.raw.factory.UserServiceFactory;
import so.raw.service.IfUserService;

public class LoginServlet extends HttpServlet {
	IfUserService us = (IfUserService) UserServiceFactory.newInstance()
			.getObject();

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/**
		 * �û���¼��setvlet
		 */
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		if (username == null || "".equals(username)) {
			response.getWriter().write("�û�������Ϊ��");
			response.setHeader("refresh", "1;login.jsp");
			return;
		}
		if (password == null || "".equals(password)) {
			response.getWriter().write("���벻��Ϊ��");
			response.setHeader("refresh", "1;login.jsp");
			return;
		}
		if (us.findUser(username, password)) {
			User user = us.findUserByName(username);
			request.getSession().setAttribute("user", user);
			response.getWriter().write("��¼�ɹ�");
			response.sendRedirect("index.jsp");
		} else {
			response.getWriter().write("�û������������");
			response.setHeader("refresh", "1;login.jsp");
		}
	}

}
