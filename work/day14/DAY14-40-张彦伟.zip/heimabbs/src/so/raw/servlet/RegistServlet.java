package so.raw.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import so.raw.domain.User;
import so.raw.factory.UserServiceFactory;
import so.raw.javabean.FormBean;
import so.raw.service.IfUserService;
import so.raw.utils.BeanTools;

public class RegistServlet extends HttpServlet {

	IfUserService us = (IfUserService) UserServiceFactory.newInstance()
			.getObject();

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			FormBean formBean = BeanTools.fillBean(FormBean.class,
					request.getParameterMap());
			request.removeAttribute("infos");
			if (formBean.test()) {
				User u = new User(formBean.getUsername(),
						formBean.getPassword(), formBean.getEmail(),
						formBean.getBirthday());
				if(us.findUserByName(formBean.getUsername())!=null)
				{
					formBean.getErrors().put("username", "�û����Ѿ�����");
					request.setAttribute("infos", formBean);
					RequestDispatcher dispatcher = request
							.getRequestDispatcher("regist.jsp");
					dispatcher.forward(request, response);
				}
				us.save(u);
				request.getSession().setAttribute("user", u);
				response.sendRedirect("index.jsp");
			} else {
				request.setAttribute("infos", formBean);
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("regist.jsp");
				dispatcher.forward(request, response);
				return;
			}
		} catch (Exception e) {

		}
	}

}
