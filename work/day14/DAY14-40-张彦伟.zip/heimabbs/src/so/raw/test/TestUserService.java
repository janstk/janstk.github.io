package so.raw.test;

import org.dom4j.DocumentException;
import org.junit.Test;

import so.raw.domain.User;
import so.raw.factory.UserServiceFactory;
import so.raw.service.IfUserService;

public class TestUserService {

	@Test
	public void testFindUserByName() throws DocumentException
	{
//		IfUserService us = (IfUserService) UserServiceFactory.newInstance().getObject();
//
//		System.out.println(us.findUser("aaa", "123"));
//		
//		System.out.println(us.findUserByName("aaa").getEmail());
		
//		String mail = "asdasdas";
//		String regexp = "\\w+@\\w+(\\.\\w+)+";
		String mail = "111";
		String regexp = "\\d{3,8}";
		System.out.println(mail.matches(regexp));
		
	}
//	@Test
	public void testadd()
	{
		
		
	}
//	@Test
	public void testServiceAdd()
	{
		IfUserService us = (IfUserService) UserServiceFactory.newInstance().getObject();
		User u = new User("bbb","123","aaa@sina.com","1990-09-08");
		System.out.println(us.save(u));
	}
}
