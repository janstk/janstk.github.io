package so.raw.utils;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;

/**
 * JavaBean �����ࡣ
 * 
 * @author z
 * 
 */
public class BeanTools {

	/**
	 * 
	 * @param ����һ��bean
	 * @return
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 * @throws InstantiationException 
	 */
	public static <T> T fillBean(Class<T> bean, Map properties)
			throws IllegalAccessException, InvocationTargetException, InstantiationException {
		
		T instance = bean.newInstance();
		BeanUtils.populate(instance, properties);
		return instance;
	}
}
