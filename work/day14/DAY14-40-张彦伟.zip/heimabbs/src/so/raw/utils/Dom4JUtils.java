package so.raw.utils;

import java.io.FileOutputStream;
import java.io.IOException;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;


/**
 * Dom4J xml �����Ĺ�����
 * 
 * @author z
 * 
 */
public class Dom4JUtils {

	private static final String BUNDLE = Dom4JUtils.class.getClassLoader()
			.getResource("so/raw/db/users.xml").getPath();
	
	public static Document getDocument() throws DocumentException
	{
		SAXReader reader = new SAXReader();
		Document document = reader.read(BUNDLE);
		return document;
	}
	public static void write2xml(Document document) throws IOException
	{
		OutputFormat format = OutputFormat.createPrettyPrint();
		format.setEncoding("utf-8");
		XMLWriter writer = new XMLWriter(new FileOutputStream(BUNDLE), format);
		writer.write(document);
		writer.close();
	}
}
